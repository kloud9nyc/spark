from pyspark.sql.dataframe import *


def transform_boston_data(df: DataFrame):
    """
    Function used to
    :param df:
    """
    df = remove_null(df)
    df = df.filter('indus > 7')
    print("Data got Filtered and transformed")
    return df


def remove_null(df: DataFrame):
    """

    :param df:
    :return:
    """
    non_null_df = df.dropna()
    print("Null Values Removed")
    return non_null_df
