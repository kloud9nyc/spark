zip -ru9 packages.zip sparkConf read transform write schemas -x sparkConf/__pycache__/\* -x read/__pycache__/\* -x write/__pycache__/\* -x transform/__pycache__/\*  -x schemas/__pycache__/\*
    cp packages.zip ~/.
    cp jobs/job1.py ~/.
    cp configs/etl_config.json ~/.
    export ENV=local
    cd

    spark-submit --py-files packages.zip --driver-memory 2g --driver-java-options "-Dconfig_domain=hdfs -Dconfig_url=/Users/nithya/PycharmProjects/PyFlow/configs/etl_config.json" job1.py
    exit 0