from os import environ, listdir

from pyspark import SparkFiles
from pyspark.sql import SparkSession
import boto3
import json


def split_s3_path(s3_path):
    """

    :param s3_path:
    :return:
    """
    print(s3_path)
    path_parts = s3_path.replace("s3://", "").split("/")
    bucket = path_parts.pop(0)
    print(bucket)
    key = "/".join(path_parts)
    print(key)
    return bucket, key

def create_spark_session():
    """
    This function to create the spark session
    """
    env = 'ENV' in environ.keys()
    environment = environ.get('ENV')
    s3 = boto3.client('s3')

    if env:
        if environment == 'local':
            print("Local Mode Session")
            spark_builder = (
                SparkSession
                    .builder
                    .appName("sales_stg_prd_job")
                    .master("local")
                    .config("driver-memory", "2 g")
                    .config("--num-executors", "4")
            )

            spark = spark_builder.getOrCreate()

            print(spark.sparkContext.getConf().getAll())

            print("Spark Session Created")
            return spark
        elif environment == 'dev':
            print("Dev Mode Session")
            spark_builder = (
                SparkSession
                    .builder
                    .appName("sales_stg_prd_job")
                    .config("driver-memory", "5g")
            )

            spark = spark_builder.getOrCreate()
            print("Spark Session Created")
            return spark
    else:
        print("Production/Cloud Mode Session")
        spark_builder = (
            SparkSession
                .builder
                .appName("sales_stg_prd_job")
        )

        spark = spark_builder.getOrCreate()

        d_params = spark.sparkContext.getConf().get('spark.driver.extraJavaOptions').split(' ')

        for configs in d_params:
            print(configs)
            config_x = configs.split('=')
            print(config_x)
            if config_x[0] == '-Dconfig_url':
                print(config_x[1])
                s3_config_key = config_x[1]

        if s3_config_key == '':
            raise Exception("Running in Production Mode, No -Dconfig_url key found for S3 Config URL")
        bucket, key = split_s3_path(s3_config_key)

        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body']

        s3config = json.loads(content.read())

        print("Spark Session Created")
        return spark, s3config
