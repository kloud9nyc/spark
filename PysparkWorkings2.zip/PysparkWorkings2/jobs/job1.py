from pyspark import SparkFiles
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, expr
import findspark
from sparkConf.session import create_spark_session
from read.read import read_csv
from transform.transform import transform_boston_data
from write.write import write_csv_local

findspark.init("/Users/nithya/spark")

print(" Job Started")

# Spark Session
spark, config = create_spark_session()

# Read the Data
df = read_csv(spark, config)

# Transform the data
transformed_df = transform_boston_data(df)

# Write Output
write_csv_local(transformed_df, config)

print(" Job Ended")
