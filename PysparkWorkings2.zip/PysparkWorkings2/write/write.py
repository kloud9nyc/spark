from pyspark.sql.dataframe import *


def write_csv_local(df: DataFrame, config):
    """
    Function to write the ouput to CSV Local Location
    :param df:
    """
    df.write.mode('overwrite').csv(config["boston_dataset_output_path"], header=True)
    print("Output has written")
