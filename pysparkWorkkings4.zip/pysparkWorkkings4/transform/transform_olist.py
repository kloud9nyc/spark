from pyspark.sql.dataframe import *
from sparkConf.logging import Log4j


def sales_by_order_id(df: DataFrame, orderid, log: Log4j):
    """
    Function used to
    :param orderid:
    :param log:
    :param df:
    """
    df = df.select('*').where("order_id=='53cbc02ffe278ca84b6f4920d9d3ecd5'")
    df.show()
    log.warn("Data got Filtered and transformed")
    return df