from pyspark.sql import SparkSession


def create_spark_session():
    """
    This function to create the spark session
    """
    spark_builder = (
        SparkSession
            .builder
            .appName("my app")
    )

    spark = spark_builder.getOrCreate()
    print("Spark Session Created")
    return spark
