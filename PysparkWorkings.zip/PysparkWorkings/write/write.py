from pyspark.sql.dataframe import *


def write_csv_local(df: DataFrame):
    """
    Function to write the ouput to CSV Local Location
    :param df:
    """
    df.write.mode('overwrite').csv("hdfs://localhost:9000/data/boston/output/", header=True)
    print("Output has written")
