from schemas.boston_schema import boston_schema
from pyspark.sql import SparkSession


def read_csv(spark: SparkSession):
    """
    Function used to read the data from CSV
    :param spark:
    """
    data = spark.read.schema(boston_schema).option("header", "true").csv("hdfs://localhost:9000/data/boston/boston.csv")
    print("CSV Files Read")
    return data
